import java.lang.Math;
public class NodoSin extends NodoOperador{
    public NodoSin(CompositeEA izq, CompositeEA der) {
        super(izq, der);
        precedence = 0;
    }
    

    /**
     * La evaluación del nodo, evalua el derecho con seno
     * @return
     */
    @Override
    public double evalua() {
        if(izq instanceof NodoOperador||izq == null){
            return Math.sin(der.evalua());
        }
        else{
            return 0.0;
        }
    }
}
