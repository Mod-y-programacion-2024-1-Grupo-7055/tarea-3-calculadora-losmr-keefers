import java.lang.Math;
public class NodoRaizC extends NodoOperador{
    public NodoRaizC(CompositeEA izq, CompositeEA der) {
        super(null, der);
        precedence = 0;
    }
    

    /**
     * La evaluación del nodo, evalua el derecho con seno
     * @return
     */
    @Override
    public double evalua() {
         return Math.sqrt(der.evalua());
    }
}