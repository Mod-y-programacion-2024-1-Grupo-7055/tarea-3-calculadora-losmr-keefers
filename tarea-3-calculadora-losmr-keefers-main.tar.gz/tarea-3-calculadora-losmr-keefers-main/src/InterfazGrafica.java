import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.StringTokenizer;

public class InterfazGrafica extends JFrame implements ActionListener {
    private JTextField inputField;

    public InterfazGrafica() {
        setTitle("Calculadora");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        inputField = new JTextField();
        JButton calcularBoton = new JButton("Calcular");
        JButton limpiarBoton = new JButton("limp");
        JButton abrirParentesisBoton = new JButton("(");
        JButton cerrarParentesisBoton = new JButton(")");

        String[] buttonLabels = {"7", "8", "9", "/", "4", "5", "6", "*", "1", "2", "3", "-", "0", "+", "sqrt", "sin", "cos", "tan"};
        JPanel buttonPanel = new JPanel(new GridLayout(5, 4, 10, 10));

        for (String label : buttonLabels) {
            JButton button = new JButton(label);
            button.addActionListener(this);
            buttonPanel.add(button);
        }

        // Configurar el diseño
        setLayout(new BorderLayout());

        // Agregar componentes a la ventana
        add(inputField, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);

        // Agregar botones de paréntesis y clear a un panel
        JPanel panelInferior = new JPanel(new GridLayout(2, 2, 10, 10));
        panelInferior.add(abrirParentesisBoton);
        panelInferior.add(cerrarParentesisBoton);
        panelInferior.add(calcularBoton);
        panelInferior.add(calcularBoton);
        add(panelInferior, BorderLayout.SOUTH);

        // Agregar acción a los botones
        calcularBoton.addActionListener(this);
        abrirParentesisBoton.addActionListener(this);
        cerrarParentesisBoton.addActionListener(this);
        calcularBoton.addActionListener(this);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() instanceof JButton) {
            JButton clickedButton = (JButton) e.getSource();
            String buttonText = clickedButton.getText();

            if (buttonText.equals("Calcular")) {
                try {
                    String expresion = inputField.getText();
                    expresion = procesarFuncionesTrigonometricas(expresion); // Procesar funciones trigonométricas antes del análisis léxico
                    Compilador comp = new Compilador();
                    StringTokenizer lexemas = comp.analisisLexico(expresion);
                    CompositeEA nodo = comp.arbolDeAnalisisSintactico(lexemas);
                    JOptionPane.showMessageDialog(this, "Resultado: " + nodo.evalua(), "Resultado", JOptionPane.INFORMATION_MESSAGE);
                } catch (ErrorDeSintaxisException ex) {
                    JOptionPane.showMessageDialog(this, "Error de sintaxis: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else if (buttonText.equals("Clear")) {
                inputField.setText(""); // Limpiar el campo de entrada
            } else {
                // Si se hace clic en un botón numérico, operador, función o paréntesis, agregar el texto al campo de entrada
                inputField.setText(inputField.getText() + buttonText);
            }
        }
    }

    private String procesarFuncionesTrigonometricas(String expresion) {
        expresion = expresion.replace("sin", "s");
        expresion = expresion.replace("cos", "c");
        expresion = expresion.replace("tan", "t");
        return expresion;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            InterfazGrafica calculadora = new InterfazGrafica();
            calculadora.setVisible(true);
        });
    }
}
