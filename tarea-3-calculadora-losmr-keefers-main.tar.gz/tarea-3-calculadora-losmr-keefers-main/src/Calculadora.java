import java.util.Scanner;
import java.util.StringTokenizer;



/**
 *
 * @author Alejandro Hernández Mora <alejandrohmora@ciencias.unam.mx>
 */
public class Calculadora {
    static Compilador comp;

    public static void calculadoraBucleada() {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("Ingresa tu operacion\n --raiz cuadrada = r \n --seno = s \n --coseno = c \n --tangente = t \n --multiplicacion = * \n --division = / \n --suma = + \n --resta = - \n --parentesis = () \n");
            String cadena = scanner.nextLine();
            comp = new Compilador();
            StringTokenizer lexemas = comp.analisisLexico(cadena);
            CompositeEA nodo = comp.arbolDeAnalisisSintactico(lexemas);
            System.out.println(nodo);
            System.out.println(nodo.evalua());
        } catch (ErrorDeSintaxisException e) {
            System.out.println("Error de sintaxis: " + e.getMessage());
        }

        System.out.print("¿Deseas hacer otra operacion?\n--si\n--no\n");
        String respuesta = scanner.nextLine();

        if ("si".equals(respuesta)) {
            Calculadora.calculadoraBucleada();
        } else if ("no".equals(respuesta)) {
            scanner.close();
        } else {
            System.out.println("Ingresa una respuesta coherente :((");
        }
    }
   
    /**
     * @param args the command line arguments
     * @throws ErrorDeSintaxisException
     */
    public static void main(String[] args) throws ErrorDeSintaxisException{
        Calculadora.calculadoraBucleada();
    }
}