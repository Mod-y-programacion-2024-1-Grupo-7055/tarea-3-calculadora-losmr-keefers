import java.lang.Math;
public class NodoCos extends NodoOperador{
    public NodoCos(CompositeEA izq, CompositeEA der) {
        super(null, der);
        precedence = 0;
    }
    

    /**
     * La evaluación del nodo, evalua el derecho con seno
     * @return
     */
    @Override
    public double evalua() {
         return Math.cos(der.evalua());
    }
}